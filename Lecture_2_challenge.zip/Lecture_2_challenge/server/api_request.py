import requests
import json

# Use request.get() to fetch from an external api 
# Lets use this one! https://api.breakingbadquotes.xyz/v1/quotes/5
# So create a method that will get the above and return it (Add .content!)
# Now we can print it and see what we get! We can even json.loads that
# return and json.dumps to format it!
# EX: json.dumps(json.load(content), indent = 4, sort_keys=true)
